 <?php 
error_reporting(E_ERROR);
 ?>

 <?php
if (isset($_POST['submit'])){

$datab = $_POST['datab'];

$A = empty($_POST['varA']) ? '' : $_POST['varA'];

$B = empty($_POST['varB']) ? '' : $_POST['varB'];

$C = empty($_POST['varC']) ? '' : $_POST['varC'];

$D = empty($_POST['varD']) ? '' : $_POST['varD'];

$E = empty($_POST['varE']) ? '' : $_POST['varE'];

$F = empty($_POST['varF']) ? '' : $_POST['varF'];

$G = empty($_POST['varG']) ? '' : $_POST['varG'];
$H = empty($_POST['varH']) ? '' : $_POST['varH'];

$I = empty($_POST['varI']) ? '' : $_POST['varI'];
$J = empty($_POST['varJ']) ? '' : $_POST['varJ'];


if(!isset($datab) || trim($datab) == '') {echo "<script>alert('Something is empty')</script>";}

else {
require 'database/db.php';
if($datab <= 10){

mysql_query("DROP TABLE IF EXISTS model");

mysql_query("DROP TABLE IF EXISTS model2");

mysql_query("DROP TABLE IF EXISTS satisfy");

mysql_query("CREATE TABLE IF NOT EXISTS `model` (`id` int(4) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
   `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
   `E` varchar(100) NOT NULL,
  `F` varchar(100) NOT NULL,
   `G` varchar(100) NOT NULL,
  `H` varchar(100) NOT NULL,
   `I` varchar(100) NOT NULL,
  `J` varchar(100) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=latin1");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");

mysql_query("CREATE TABLE IF NOT EXISTS `model2` (`id` int(4) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
   `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
   `E` varchar(100) NOT NULL,
  `F` varchar(100) NOT NULL,
   `G` varchar(100) NOT NULL,
  `H` varchar(100) NOT NULL,
   `I` varchar(100) NOT NULL,
  `J` varchar(100) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=latin1");

mysql_query("INSERT INTO model2(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");

mysql_query("CREATE TABLE IF NOT EXISTS `satisfy` (`id` int(4) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
   `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
   `E` varchar(100) NOT NULL,
  `F` varchar(100) NOT NULL,
   `G` varchar(100) NOT NULL,
  `H` varchar(100) NOT NULL,
   `I` varchar(100) NOT NULL,
  `J` varchar(100) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=latin1");

mysql_query("INSERT INTO satisfy(id, A, B, C, D, E, F, G, H, I, J) VALUES('1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0')");

 $query1=mysql_query("SELECT * FROM model2 WHERE id = '1'");
  $query2=mysql_query("SELECT * FROM satisfy WHERE id = '1'");

$row1 = mysql_fetch_array($query1);
$row2 = mysql_fetch_array($query2);

$A = $row1['A'];

$B = $row1['B'];

$C = $row1['C'];

$D = $row1['D'];

$E = $row1['E'];

$F = $row1['F'];

$G = $row1['G'];
$H = $row1['H'];

$I = $row1['I'];
$J = $row1['J'];

$satA = $row2['A'];

$satB = $row2['B'];

$satC = $row2['C'];

$satD = $row2['D'];

$satE = $row2['E'];

$satF = $row2['F'];

$satG = $row2['G'];
$satH = $row2['H'];
$satI = $row2['I'];
$satJ = $row2['J'];

$$_POST['con1A'] = $$_POST['con1A'];
$$_POST['con1B'] = $$_POST['con1B'];
$$_POST['con1C'] = $$_POST['con1C'];
$$_POST['con1D'] = $$_POST['con1D'];
$$_POST['con1E'] = $$_POST['con1E'];
$$_POST['con1F'] = $$_POST['con1F'];
$$_POST['con1G'] = $$_POST['con1G'];
$$_POST['con1H'] = $$_POST['con1H'];
$$_POST['con1I'] = $$_POST['con1I'];
$$_POST['con1J'] = $$_POST['con1J'];



$$_POST['con2A'] = $$_POST['con2A'];
$$_POST['con2B'] = $$_POST['con2B'];
$$_POST['con2C'] = $$_POST['con2C'];
$$_POST['con2D'] = $$_POST['con2D'];
$$_POST['con2E'] = $$_POST['con2E'];
$$_POST['con2F'] = $$_POST['con2F'];
$$_POST['con2G'] = $$_POST['con2G'];
$$_POST['con2H'] = $$_POST['con2H'];
$$_POST['con2I'] = $$_POST['con2I'];
$$_POST['con2J'] = $$_POST['con2J'];




$$_POST['conAprim'] = $_POST['conAprim'];
$$_POST['conBprim'] = $_POST['conBprim'];
$$_POST['conCprim'] = $_POST['conCprim'];
$$_POST['conDprim'] = $_POST['conDprim'];
$$_POST['conEprim'] = $_POST['conEprim'];
$$_POST['conFprim'] = $_POST['conFprim'];
$$_POST['conGprim'] = $_POST['conGprim'];
$$_POST['conHprim'] = $_POST['conHprim'];
$$_POST['conIprim'] = $_POST['conIprim'];
$$_POST['conJprim'] = $_POST['conJprim'];


$$_POST['varA'] = $_POST['conCprim'];
$$_POST['varB'] = $_POST['con2B'];


while($satA != '1' || $satB != '1' || $satC != '1' || $satD != '1' || $satE != '1' || $satF != '1' || $satG != '1' || $satH != '1' || $satI != '1' || $satJ != '1'){

if($$_POST['conAprim'] == 'equal') {

 if($$_POST['con1A'] > $$_POST['con2A']){


$$_POST['con1A']  = $$_POST['con1A'] ;
$$_POST['con2A']  = $$_POST['con2A'] + 1;

 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");

}




 elseif($$_POST['con1A'] < $$_POST['con2A']){

$$_POST['con1A']  = $$_POST['con1A'] + 1;
$$_POST['con2A']  = $$_POST['con2A'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");
}




 elseif($$_POST['con1A'] = $$_POST['con2A'])
 {

$$_POST['con1A']  = $$_POST['con1A'];
$$_POST['con2A']  = $$_POST['con2A'];



 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");
 mysql_query("UPDATE satisfy SET A='1' where id = '1'");

}

}
 


elseif($$_POST['conAprim'] == 'unequal') {
if($$_POST['con1A'] > $$_POST['con2A']){

$$_POST['con1A']  = $$_POST['con1A'] ;
$$_POST['con2A']  = $$_POST['con2A'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");     
 mysql_query("UPDATE satisfy SET A='1' where id = '1'");
}

 elseif($$_POST['con1A'] < $$_POST['con2A']){
$$_POST['con1A']  = $$_POST['con1A'];
$$_POST['con2A']  = $$_POST['con2A'];

 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");     
mysql_query("UPDATE satisfy SET A='1' where id = '1'");

}

 elseif($$_POST['con1A'] = $$_POST['con2A']){

$$_POST['con1A']  = $$_POST['con1A'];
$$_POST['con2A']  = $$_POST['con2A'] + 1;

 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");
    
 mysql_query("UPDATE satisfy SET A='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");

}

}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


  if($$_POST['conBprim'] == 'equal') {

 if($$_POST['con1B'] > $$_POST['con2B']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1B']  = $$_POST['con1B'] ;
$$_POST['con2B']  = $$_POST['con2B'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1B'] < $$_POST['con2B']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1B']  = $$_POST['con1B'] + 1;
$$_POST['con2B']  = $$_POST['con2B'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1B'] = $$_POST['con2B'])
 {

$$_POST['con1B']  = $$_POST['con1B'];
$$_POST['con2B']  = $$_POST['con2B'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1B']  = $$_POST['con1B'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET B='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conBprim'] == 'unequal') {
if($$_POST['con1B'] > $$_POST['con2B']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1B']  = $$_POST['con1B'] ;
$$_POST['con2B']  = $$_POST['con2B'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET B='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


      //echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1B'] < $$_POST['con2B']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1B']  = $$_POST['con1B'];
$$_POST['con2B']  = $$_POST['con2B'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET B='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1B'] = $$_POST['con2B'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1B'] = $$_POST['con2B']){

$$_POST['con1B']  = $$_POST['con1B'];
$$_POST['con2B']  = $$_POST['con2B'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1B']  = $$_POST['con1B'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET B='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





  if($$_POST['conCprim'] == 'equal') {

 if($$_POST['con1C'] > $$_POST['con2C']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1C']  = $$_POST['con1C'] ;
$$_POST['con2C']  = $$_POST['con2C'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1C'] < $$_POST['con2C']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1C']  = $$_POST['con1C'] + 1;
$$_POST['con2C']  = $$_POST['con2C'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1C'] = $$_POST['con2C'])
 {

$$_POST['con1C']  = $$_POST['con1C'];
$$_POST['con2C']  = $$_POST['con2C'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1C']  = $$_POST['con1C'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy set C='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conCprim'] == 'unequal') {
if($$_POST['con1C'] > $$_POST['con2C']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1C']  = $$_POST['con1C'] ;
$$_POST['con2C']  = $$_POST['con2C'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy set C='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1C'] < $$_POST['con2C']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1C']  = $$_POST['con1C'];
$$_POST['con2C']  = $$_POST['con2C'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy set C='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1C'] = $$_POST['con2C'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1C'] = $$_POST['con2C']){

$$_POST['con1C']  = $$_POST['con1C'];
$$_POST['con2C']  = $$_POST['con2C'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1C']  = $$_POST['con1C'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy set C='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



  if($$_POST['conDprim'] == 'equal') {

 if($$_POST['con1D'] > $$_POST['con2D']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1D']  = $$_POST['con1D'] ;
$$_POST['con2D']  = $$_POST['con2D'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1D'] < $$_POST['con2D']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1D']  = $$_POST['con1D'] + 1;
$$_POST['con2D']  = $$_POST['con2D'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1D'] = $$_POST['con2D'])
 {

$$_POST['con1D']  = $$_POST['con1D'];
$$_POST['con2D']  = $$_POST['con2D'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1D']  = $$_POST['con1D'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET D='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conDprim'] == 'unequal') {
if($$_POST['con1D'] > $$_POST['con2D']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1D']  = $$_POST['con1D'] ;
$$_POST['con2D']  = $$_POST['con2D'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET D='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1D'] < $$_POST['con2D']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1D']  = $$_POST['con1D'];
$$_POST['con2D']  = $$_POST['con2D'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET D='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1D'] = $$_POST['con2D'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1D'] = $$_POST['con2D']){

$$_POST['con1D']  = $$_POST['con1D'];
$$_POST['con2D']  = $$_POST['con2D'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1D']  = $$_POST['con1D'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET D='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




  if($$_POST['conEprim'] == 'equal') {

 if($$_POST['con1E'] > $$_POST['con2E']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1E']  = $$_POST['con1E'] ;
$$_POST['con2E']  = $$_POST['con2E'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1E'] < $$_POST['con2E']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1E']  = $$_POST['con1E'] + 1;
$$_POST['con2E']  = $$_POST['con2E'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1E'] = $$_POST['con2E'])
 {

$$_POST['con1E']  = $$_POST['con1E'];
$$_POST['con2E']  = $$_POST['con2E'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1E']  = $$_POST['con1E'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET E='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conEprim'] == 'unequal') {
if($$_POST['con1E'] > $$_POST['con2E']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1E']  = $$_POST['con1E'] ;
$$_POST['con2E']  = $$_POST['con2E'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET E='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1E'] < $$_POST['con2E']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1E']  = $$_POST['con1E'];
$$_POST['con2E']  = $$_POST['con2E'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET E='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1E'] = $$_POST['con2E'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1E'] = $$_POST['con2E']){

$$_POST['con1E']  = $$_POST['con1E'];
$$_POST['con2E']  = $$_POST['con2E'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1E']  = $$_POST['con1E'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET E='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




  if($$_POST['conFprim'] == 'equal') {

 if($$_POST['con1F'] > $$_POST['con2F']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1F']  = $$_POST['con1F'] ;
$$_POST['con2F']  = $$_POST['con2F'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1F'] < $$_POST['con2F']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1F']  = $$_POST['con1F'] + 1;
$$_POST['con2F']  = $$_POST['con2F'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1F'] = $$_POST['con2F'])
 {

$$_POST['con1F']  = $$_POST['con1F'];
$$_POST['con2F']  = $$_POST['con2F'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1F']  = $$_POST['con1F'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET F='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conFprim'] == 'unequal') {
if($$_POST['con1F'] > $$_POST['con2F']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1F']  = $$_POST['con1F'] ;
$$_POST['con2F']  = $$_POST['con2F'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET F='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1F'] < $$_POST['con2F']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1F']  = $$_POST['con1F'];
$$_POST['con2F']  = $$_POST['con2F'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET F='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1F'] = $$_POST['con2F'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1F'] = $$_POST['con2F']){

$$_POST['con1F']  = $$_POST['con1F'];
$$_POST['con2F']  = $$_POST['con2F'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1F']  = $$_POST['con1F'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET F='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



  if($$_POST['conGprim'] == 'equal') {

 if($$_POST['con1G'] > $$_POST['con2G']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1G']  = $$_POST['con1G'] ;
$$_POST['con2G']  = $$_POST['con2G'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1G'] < $$_POST['con2G']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1G']  = $$_POST['con1G'] + 1;
$$_POST['con2G']  = $$_POST['con2G'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1G'] = $$_POST['con2G'])
 {

$$_POST['con1G']  = $$_POST['con1G'];
$$_POST['con2G']  = $$_POST['con2G'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1G']  = $$_POST['con1G'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET G='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conGprim'] == 'unequal') {
if($$_POST['con1G'] > $$_POST['con2G']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1G']  = $$_POST['con1G'] ;
$$_POST['con2G']  = $$_POST['con2G'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET G='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1G'] < $$_POST['con2G']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1G']  = $$_POST['con1G'];
$$_POST['con2G']  = $$_POST['con2G'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET G='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1G'] = $$_POST['con2G'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1G'] = $$_POST['con2G']){

$$_POST['con1G']  = $$_POST['con1G'];
$$_POST['con2G']  = $$_POST['con2G'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1G']  = $$_POST['con1G'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET G='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





  if($$_POST['conHprim'] == 'equal') {

 if($$_POST['con1H'] > $$_POST['con2H']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1H']  = $$_POST['con1H'] ;
$$_POST['con2H']  = $$_POST['con2H'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1H'] < $$_POST['con2H']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1H']  = $$_POST['con1H'] + 1;
$$_POST['con2H']  = $$_POST['con2H'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1H'] = $$_POST['con2H'])
 {

$$_POST['con1H']  = $$_POST['con1H'];
$$_POST['con2H']  = $$_POST['con2H'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1H']  = $$_POST['con1H'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET H='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conHprim'] == 'unequal') {
if($$_POST['con1H'] > $$_POST['con2H']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1H']  = $$_POST['con1H'] ;
$$_POST['con2H']  = $$_POST['con2H'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET H='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1H'] < $$_POST['con2H']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1H']  = $$_POST['con1H'];
$$_POST['con2H']  = $$_POST['con2H'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET H='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1H'] = $$_POST['con2H'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1H'] = $$_POST['con2H']){

$$_POST['con1H']  = $$_POST['con1H'];
$$_POST['con2H']  = $$_POST['con2H'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1H']  = $$_POST['con1H'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET H='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



  if($$_POST['conIprim'] == 'equal') {

 if($$_POST['con1I'] > $$_POST['con2I']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1I']  = $$_POST['con1I'] ;
$$_POST['con2I']  = $$_POST['con2I'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1I'] < $$_POST['con2I']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1I']  = $$_POST['con1I'] + 1;
$$_POST['con2I']  = $$_POST['con2I'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1I'] = $$_POST['con2I'])
 {

$$_POST['con1I']  = $$_POST['con1I'];
$$_POST['con2I']  = $$_POST['con2I'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1I']  = $$_POST['con1I'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET I='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conIprim'] == 'unequal') {
if($$_POST['con1I'] > $$_POST['con2I']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1I']  = $$_POST['con1I'] ;
$$_POST['con2I']  = $$_POST['con2I'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET I='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1I'] < $$_POST['con2I']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1I']  = $$_POST['con1I'];
$$_POST['con2I']  = $$_POST['con2I'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET I='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1I'] = $$_POST['con2I'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1I'] = $$_POST['con2I']){

$$_POST['con1I']  = $$_POST['con1I'];
$$_POST['con2I']  = $$_POST['con2I'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1I']  = $$_POST['con1I'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET I='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



  if($$_POST['conJprim'] == 'equal') {

 if($$_POST['con1J'] > $$_POST['con2J']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1J']  = $$_POST['con1J'] ;
$$_POST['con2J']  = $$_POST['con2J'] + 1;
//$satA = $satA;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 //mysql_query("UPDATE satisfy SET A='$satA' where id = '1'");

 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


    //  echo "<script>alert('$B')</script>";
}



 elseif($$_POST['con1J'] < $$_POST['con2J']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
$$_POST['con1J']  = $$_POST['con1J'] + 1;
$$_POST['con2J']  = $$_POST['con2J'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


 mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


 //mysql_query("UPDATE satisfy SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 elseif($$_POST['con1J'] = $$_POST['con2J'])
 {

$$_POST['con1J']  = $$_POST['con1J'];
$$_POST['con2J']  = $$_POST['con2J'];

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1J']  = $$_POST['con1J'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET J='1' where id = '1'");





//echo "<script>alert('We Have An Answer')</script>";
}

}
 
elseif($$_POST['conJprim'] == 'unequal') {
if($$_POST['con1J'] > $$_POST['con2J']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1J']  = $$_POST['con1J'] ;
$$_POST['con2J']  = $$_POST['con2J'] ;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
 mysql_query("UPDATE satisfy SET J='1' where id = '1'");



 //mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");


  //    echo "<script>alert('Answer gotten')</script>";
}



 elseif($$_POST['con1J'] < $$_POST['con2J']){



    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");

$$_POST['con1J']  = $$_POST['con1J'];
$$_POST['con2J']  = $$_POST['con2J'];


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
     
mysql_query("UPDATE satisfy SET J='1' where id = '1'");


//echo "<script>alert('One Solution achieved')</script>";
      //echo "<script>alert('$A')</script>";
}




 //if($$_POST['con1J'] = $$_POST['con2J'] && $$_POST['conAprim'] == 'unequal')
 elseif($$_POST['con1J'] = $$_POST['con2J']){

$$_POST['con1J']  = $$_POST['con1J'];
$$_POST['con2J']  = $$_POST['con2J'] + 1;

    //$insert =mysql_query("INSERT INTO model(id, A, B, C) VALUES('1', '$A', '$B', '$C')");
//$$_POST['con1J']  = $$_POST['con1J'] + 1;


 mysql_query("UPDATE model2 SET A='$A', B='$B', C='$C', D='$D', E='$E', F='$F', G='$G', H='$H', I='$I', J='$J' where id = '1'");

//echo "<script>alert('One Solution achieved')</script>";
      

 mysql_query("UPDATE satisfy SET J='1' where id = '1'");

mysql_query("INSERT INTO model(id, A, B, C, D, E, F, G, H, I, J) VALUES('', '$A', '$B', '$C', '$D', '$E', '$F', '$G', '$H', '$I', '$J')");





//echo "<script>alert('We Have An Answer')</script>";
}


}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
echo "<script>alert('Iterations Now Complete');window.location='result.php'</script>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//while ($satB != '1') {


//}

//else{

  //echo "<script>alert('Terminate')</script>";

//}

 

//$$_POST['conA'] = $_POST['A'];

 //$update=mysql_query("INSERT INTO model2(a, b, c) VALUES('$A', '$B', '$C')");

}

  //if ($update) 
  
}

}
?>              