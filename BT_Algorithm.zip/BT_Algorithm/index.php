
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>A Case Study for Bus Route Allocation System</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top" id="mainNav">
    <a class="navbar-brand" href="#" style="font-size: 23px">Using Backtracking Algorithm To Solve Number Domain Problem As A Case Study</a>
    <a class="navbar-brand" href="#" style="margin-left:920px"></a>
   
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="active nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="index.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
<br>

         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Result">
          <a class="nav-link" href="result.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Result</span>
          </a>
        </li>     
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#" style="color:green"></a>
        </li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
      
<form method="POST" action="backtracking_algorithm.php">
      <div class="row">
        <div class="col-lg-12">
          <!-- Example Bar Chart Card-->
          <div class="card mb-3">
            <div class="card-header">
               <p style="font-size:20px;color:green">Note: Number of Variable Should Range Between 3 and 10<br>
               </p>
             </div>
            <div class="card-body">
              <div class="row">
        
        <div class="col-lg-3 my-auto">
          <!-- Example Pie Chart Card-->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fa fa-fw fa-table"></i> Declare Number of Variables </div>
            <div class="card-body">
  <input type="text" name="datab" id="datab" value="" style="width: 8px; height: 8px">
     <div id="dynamicInput">
          <br><br><br>

          <input type="text" name="A" id="increase" value="3" style="">
     </div>
     <input type="button" id="button1" value="Generate Input Variables" onClick="addInput('dynamicInput');">
     <br><br><br>

     </div>
</div></div>
<div class="col-lg-3">
          <!-- Example Pie Chart Card-->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fa fa-fw fa-table"></i> Declare Value for Each Variable</div>
            <div class="card-body">
<br><br><br><br>
<input type="text" name="varA" id="inputvalue" value="" style="">
   <div id="varValue"> 
         
</div>
     <input type="button" id="button2" value="Generate Value Fields" onClick="varInput('varValue');">
</div>

<br><br>
</div>
</div>
<div class="col-lg-2">
<div class="card mb-3">
            <div class="card-header">
               Constraint Value 1</div>
            <div class="card-body">
  <div class="col-sm-12">
   <div id="conInput"> 
     <input type="text" name="convalues" id="convalues" value="" style="width: 8px;height: 8px"><i style="font-size: 13px;color:green">Select Number of Conditions</i>
          <br><br>

 <select type="select" name="con1A" id="constraint" value="" style="height: 30px;width: 68px">
            <option value="1" id="opt1">1</option>
            <option value="2" id="opt2">2</option>
            <option value="3" id="opt3">3</option>
            <option value="4" id="opt4">4</option>
            <option value="5" id="opt5">5</option>
            <option value="6" id="opt6">6</option>
            <option value="7" id="opt7">7</option>
            <option value="8" id="opt8">8</option>
            <option value="9" id="opt9">9</option>
            <option value="10" id="opt10">10</option>
          </select>
     </div>
     <input type="button" id="button3" style="width: 68px;" value="Populate" onClick="secondInput('conInput');">

</div>

</div>
<br><br>


</div>
</div>
<div class="col-lg-2">
<div class="card mb-3">
            <div class="card-header">
              Constraint Value 2</div>
            <div class="card-body">
<!-- -->
<div class="col-lg-6 well" style="float:">

   <div id="conInput2"> 
     
          <br><br><br><br>

          <select type="select" name="con2A" id="constraint2" value="" style="height: 30px;width: 68px">
            <option value="1" id="opt1">1</option>
            <option value="2" id="opt2">2</option>
            <option value="3" id="opt3">3</option>
            <option value="4" id="opt4">4</option>
            <option value="5" id="opt5">5</option>
            <option value="6" id="opt6">6</option>
            <option value="7" id="opt7">7</option>
            <option value="8" id="opt8">8</option>
            <option value="9" id="opt8">9</option>
            <option value="10" id="opt8">10</option>
          </select>
     </div>
     <input type="button" id="button4" style="width: 68px;" value="Populate" onClick="thirdInput('conInput2');">

</div>
</div>
<br><br>
</div>
</div>

<div class="col-lg-2">
          <div class="card mb-3">
            <div class="card-header">
              Constraints Condition</div>
            <div class="card-body">

   <div id="conOutput">
    <br><br><br><br>

          <select type="select" name="conAprim" id="constp" value="" style="height: 30px">
            <option value="equal">equal</option>
            <option value="unequal">unequal</option>
          </select>
     </div>
     <input type="button" id="primbutton" value="Populate" onClick="valueCon('conOutput');" style="width: 82px">

</div>
<br><br>
</div>
</div>
             

<button type="submit" name="submit"  class="btn btn-primary-green" style="background-color:green;color:white;margin-left:0px;width:100%">Execute Algorithm</button>


</div></div></div></div></div>
</form>
<canvas id="myPieChart" width="100%" height="100"></canvas>
</div>
<div class="card-footer small text-muted"></div>
</div>
          
</div>
</div>
      
   
    </div>
 
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Bus Route Allocation System Using Backtracking Algorithm</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>

<script language="Javascript" type="text/javascript">



var counter = 1;
var limit = 10;

function addInput(divName){

 var number = document.getElementById("increase").value;


     if (number > 10 || number < 2)  {
          alert("The Minimum Number of variables you can have is 2 while the Maximum is 10");
     }
     else {

      for (i = 0; i < number -1; i++) {

          var newdiv = document.createElement('div');
           
j = i + 66;

var letter = String.fromCharCode(j);
var input = document.createElement("input");
            input.type = "text";
            input.name = letter;
            
            input.value = letter;

            
            newdiv.appendChild(input);

        
          document.getElementById(divName).appendChild(newdiv);

          counter++;


        }
        var inc = document.getElementById("increase");
          inc.value = "A";
var con = document.getElementById("datab");
var con2 = document.getElementById("inputvalue");
          con.value = number;
          con2.value = number;
document.getElementById('button1').disabled = true;
     }
}


</script>


<script language="Javascript" type="text/javascript">



var counter = 1;
var limit = 10;

function varInput(divName){

 var number = document.getElementById("datab").value;


     if (number > 10 || number < 2)  {
          alert("The Minimum Number of variables you can have is 2 while the Maximum is 10");
     }
     else {

       for (i = 0; i < number -1; i++) {

          var newdiv = document.createElement('div');
           
j = i + 66;

var letter = String.fromCharCode(j);
var input = document.createElement("input");
            input.type = "text";
            input.name = "var"+letter;
            
            input.value = "";
            input.placeholder = "Numeric value for "+letter;

            
            newdiv.appendChild(input);

        
          document.getElementById(divName).appendChild(newdiv);

          counter++;


        }

var inc = document.getElementById("inputvalue");
          inc.value = "";
          inc.placeholder = "Numeric Value for A";
          document.getElementById('button2').disabled = true;
     }
}


</script>

<script type="text/javascript">
function secondInput(divName){

 var number = document.getElementById("constraint").value;

     if (number > 10 || number < 2)  {
          alert("The Minimum Number of variables you can have is 2 while the Maximum is 10");
     }
     else {

      for (i = 0; i < number -1; i++) {

          var newdiv = document.createElement('div');
           
j = i + 66;

var letter = String.fromCharCode(j);
var select = document.createElement("select");

var select_name = "con1"+letter;

select.name = "con1"+letter;
   //select.setAttribute("name", select_name);
    //select.setAttribute("id", select_name);
    select.style.width = "68px";
     select.style.height = "30px";

var option;
option = document.createElement("option");
   option.setAttribute("value", "");
   option.innerHTML = "select";
   select.appendChild(option);
     

   numopt = document.getElementById('datab').value;

for (x = 0; x < numopt; x++){
   y = x + 65;
  var leta = String.fromCharCode(y);
    var opt = document.createElement('option');
    opt.value = leta;
    opt.innerHTML = leta;
    select.appendChild(opt);
}

    /* setting an onchange event */
  //  selectNode.onchange = function() {dbrOptionChange()};
     
/*   var option;
   var optionb;
    var optionc;
     var optiond;
      var optione;
       var optionf;
        var optiong;
         var optionh;
          var optioni;
           var optionj;
    
   /* we are going to add two options */
   /* create options elements */
  /* option = document.createElement("option");
   option.setAttribute("value", "A");
   option.innerHTML = "A";
   select.appendChild(option);

    
   optionb = document.createElement("option");
 optionb.setAttribute("value", "B");
 optionb.innerHTML = "B";
  select.appendChild(optionb);


  optionc = document.createElement("option");
 optionc.setAttribute("value", "C");
 optionc.innerHTML = "C";
  select.appendChild(optionc);

  optiond = document.createElement("option");
 optiond.setAttribute("value", "D");
 optiond.innerHTML = "D";
  select.appendChild(optiond);


  optione = document.createElement("option");
 optione.setAttribute("value", "E");
 optione.innerHTML = "E";
  select.appendChild(optione);


  optionf = document.createElement("option");
 optionf.setAttribute("value", "F");
 optionf.innerHTML = "F";
  select.appendChild(optionf);

  optiong = document.createElement("option");
 optiong.setAttribute("value", "G");
 optiong.innerHTML = "G";
  select.appendChild(optiong);

  optionh = document.createElement("option");
 optionh.setAttribute("value", "H");
 optionh.innerHTML = "H";
  select.appendChild(optionh);

  optioni = document.createElement("option");
 optioni.setAttribute("value", "I");
 optioni.innerHTML = "I";
  select.appendChild(optioni);

  optionj = document.createElement("option");
 optionj.setAttribute("value", "J");
 optionj.innerHTML = "J";
  select.appendChild(optionj);    */ 

            
            newdiv.appendChild(select);


        
          document.getElementById(divName).appendChild(newdiv);


          
        }
var rmOption = document.getElementById("constraint");
rmOption.options.length = 0;


 numopt2 = document.getElementById('datab').value;
y = x + 64;
var min = 65,
    max = y,
    select = document.getElementById('constraint');

for (var i = min; i<=max; i++){
  var letter = String.fromCharCode(i);
    var opt = document.createElement('option');
    opt.value = letter;
    opt.innerHTML = letter;
    select.appendChild(opt);
}
document.getElementById('button3').disabled = true;


        //var inc = document.getElementById("constraint").appendChild("option");
          
          // inc.innerHTML= "A";
           //inc.value = "B";

          var incval = document.getElementById("convalues");
          var con2val = document.getElementById("constraint2");
          var conval2 = document.getElementById("convalues2");
          
          incval.value = number;
          con2val.value = number;
          conval2.value = number;



     }
}


</script>



<script type="text/javascript">
function thirdInput(divName){

 var number = document.getElementById("convalues").value;
 var number2 = document.getElementById("constraint2").value;


     if (number != number2)  {
          alert("The Number Of Generated Rows for Primary and Secondary MUST be Equal");
     }
     else {

        for (i = 0; i < number -1; i++) {

          var newdiv = document.createElement('div');
           
j = i + 66;

var letter = String.fromCharCode(j);
var select = document.createElement("select");

var select_name = "con2"+letter;

select.name = "con2"+letter;
   //select.setAttribute("name", select_name);
    //select.setAttribute("id", select_name);
    select.style.width = "68px";
     select.style.height = "30px";

var option;
option = document.createElement("option");
   option.setAttribute("value", "");
   option.innerHTML = "select";
   select.appendChild(option);
     

   numopt = document.getElementById('datab').value;

for (x = 0; x < numopt; x++){
   y = x + 65;
  var leta = String.fromCharCode(y);
    var opt = document.createElement('option');
    opt.value = leta;
    opt.innerHTML = leta;
    select.appendChild(opt);
}

    /* setting an onchange event */
  //  selectNode.onchange = function() {dbrOptionChange()};
     
/*   var option;
   var optionb;
    var optionc;
     var optiond;
      var optione;
       var optionf;
        var optiong;
         var optionh;
          var optioni;
           var optionj;
    
   /* we are going to add two options */
   /* create options elements */
  /* option = document.createElement("option");
   option.setAttribute("value", "A");
   option.innerHTML = "A";
   select.appendChild(option);

    
   optionb = document.createElement("option");
 optionb.setAttribute("value", "B");
 optionb.innerHTML = "B";
  select.appendChild(optionb);


  optionc = document.createElement("option");
 optionc.setAttribute("value", "C");
 optionc.innerHTML = "C";
  select.appendChild(optionc);

  optiond = document.createElement("option");
 optiond.setAttribute("value", "D");
 optiond.innerHTML = "D";
  select.appendChild(optiond);


  optione = document.createElement("option");
 optione.setAttribute("value", "E");
 optione.innerHTML = "E";
  select.appendChild(optione);


  optionf = document.createElement("option");
 optionf.setAttribute("value", "F");
 optionf.innerHTML = "F";
  select.appendChild(optionf);

  optiong = document.createElement("option");
 optiong.setAttribute("value", "G");
 optiong.innerHTML = "G";
  select.appendChild(optiong);

  optionh = document.createElement("option");
 optionh.setAttribute("value", "H");
 optionh.innerHTML = "H";
  select.appendChild(optionh);

  optioni = document.createElement("option");
 optioni.setAttribute("value", "I");
 optioni.innerHTML = "I";
  select.appendChild(optioni);

  optionj = document.createElement("option");
 optionj.setAttribute("value", "J");
 optionj.innerHTML = "J";
  select.appendChild(optionj);    */ 

            
            newdiv.appendChild(select);


        
          document.getElementById(divName).appendChild(newdiv);


          
        }
var rmOption = document.getElementById("constraint2");
rmOption.options.length = 0;


 numopt2 = document.getElementById('datab').value;
y = x + 64;
var min = 65,
    max = y,
    select = document.getElementById('constraint2');

for (var i = min; i<=max; i++){
  var letter = String.fromCharCode(i);
    var opt = document.createElement('option');
    opt.value = letter;
    opt.innerHTML = letter;
    select.appendChild(opt);
}
document.getElementById('button4').disabled = true;
          
     }

}


</script>







<script language="Javascript" type="text/javascript">



var counter = 1;
var limit = 10;

function valueCon(divName){

 var number = document.getElementById("convalues").value;


     if (number > 10 || number < 2)  {
          alert("The Minimum Number of variables you can have is 3 while the Maximum is 10");
     }
     else {

       for (i = 0; i < number -1; i++) {

          var newdiv = document.createElement('div');
           
j = i + 66;

var letter = String.fromCharCode(j);


    /* create select */
    var select = document.createElement("select");

var select_name = "con"+letter+"prim";

select.name = "con" + letter + "prim";
   //select.setAttribute("name", select_name);
    //select.setAttribute("id", select_name);
    select.style.width = "82px";
     select.style.height = "30px";


     
    /* setting an onchange event */
  //  selectNode.onchange = function() {dbrOptionChange()};
     
   var option;
   var optionb;
    
   /* we are going to add two options */
   /* create options elements */
   option = document.createElement("option");
   option.setAttribute("value", "equal");
   option.innerHTML = "equal";
   select.appendChild(option);

    
   optionb = document.createElement("option");
 optionb.setAttribute("value", "unequal");
 optionb.innerHTML = "unequal";
  select.appendChild(optionb);

            
            newdiv.appendChild(select);


        
          document.getElementById(divName).appendChild(newdiv);

          counter++;


        }
       //var con2 = document.getElementById("constp");
          //con2.value = "Equal";
document.getElementById('primbutton').disabled = true;
     }
}


</script>