
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
 <title>A Case Study for Bus Route Allocation System</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top" id="mainNav">
    <a class="navbar-brand" href="#">Using Backtracking Algorithm To Solve Number Domain Problem As A Case Study</a>
    <a class="navbar-brand" href="#" style="margin-left:920px"></a>
   
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="index.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
<br>

         <li class="active nav-item" data-toggle="tooltip" data-placement="right" title="Result">
          <a class="nav-link" href="#">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Result</span>
          </a>
        </li>
       
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#" style="color:green">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Backtracking Algorithm Results</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
        
        
       
      </div>
      <!-- Area Chart Example-->
      

      <div class="row">
        <div class="col-lg-12">
          <!-- Example Bar Chart Card-->
          <div class="card mb-3">
            <div class="card-header">
               <p style="font-size:20px;color:green">Backtracking Algorithm Results For Number Domain Problem</p></div>
  

            <div class="card-body">
              <div class="row">
                <div class="col-sm-8 my-auto">
                  <canvas id="myBarChart" width="100" height="10"></canvas>
                 
                </div>
                <div class="col-sm-12 text-center my-auto">
                  <div class="h4 mb-0 text-primary"><p style="font-size:16px;color:green">Below is the Result of the Problem using Backtracking Algorithm</p></div>

<table class="table table-striped table-bordered bootstrap-datatable datatable responsive" style="background:white">
          <thead>
          <tr>
            <th>Iteration</th>
            
             <th>A</th>
            <th>B</th>
            <th>C</th>
            <th>D</th>
            <th>E</th>
            <th>F</th>
            <th>G</th>
            <th>H</th>
            <th>I</th>
            <th>J</th>

          </tr>
          </thead>
          <tbody style="color:black">
             
  <?php 
  require 'database/db.php';
$result= mysql_query("SELECT * FROM model") or die (mysql_error());
              while ($row= mysql_fetch_array ($result) ){
              
              ?>
          
         <tr>
            <td><?php echo $row['id'];?></td>
                        
            <td><?php echo $row['A'];?></td>
            <td><?php echo $row['B'];?></td>
            <td><?php echo $row['C'];?></td>
            <td><?php echo $row['D'];?></td>
            <td><?php echo $row['E'];?></td>
            <td><?php echo $row['F'];?></td>
            <td><?php echo $row['G'];?></td>
            <td><?php echo $row['H'];?></td>
            <td><?php echo $row['I'];?></td>
            <td><?php echo $row['J'];?></td>

       <?php  } ?>

</tr>
</tbody>
</table>
<br><br>


 <a href="index.php"><button type="submit" name="iterate" class="btn btn-primary-green" 
               style="background-color:green;color:white;margin-left:0px;width:100%">Go Back</button></a>

                  <hr>
                  
                  <div class="h4 mb-0 text-success" style="font-size:16px;"> 

                  </div>
                  
                </div>
              </div>
            </div>
            <div class="card-footer small text-muted"></div>
          </div>
          
    
        </div>

   
    </div>



    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Bus Route Allocation System Using Backtracking Algorithm</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
