<?php
ob_start();
mysql_select_db('bt',mysql_connect('localhost','root',''))or die(mysql_error());
?>