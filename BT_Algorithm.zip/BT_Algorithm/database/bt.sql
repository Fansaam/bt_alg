-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2017 at 02:21 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bt`
--

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE IF NOT EXISTS `model` (
  `id` int(4) NOT NULL,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
  `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
  `E` varchar(100) NOT NULL,
  `F` varchar(100) NOT NULL,
  `G` varchar(100) NOT NULL,
  `H` varchar(100) NOT NULL,
  `I` varchar(100) NOT NULL,
  `J` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`id`, `A`, `B`, `C`, `D`, `E`, `F`, `G`, `H`, `I`, `J`) VALUES
(1, '2', '5', '7', '3', '11', '', '', '', '', ''),
(2, '3', '5', '7', '3', '11', '', '', '', '', ''),
(3, '3', '5', '7', '4', '11', '', '', '', '', ''),
(4, '4', '5', '7', '4', '11', '', '', '', '', ''),
(5, '4', '5', '7', '5', '11', '', '', '', '', ''),
(6, '5', '5', '7', '5', '11', '', '', '', '', ''),
(7, '6', '5', '7', '5', '11', '', '', '', '', ''),
(8, '7', '5', '7', '5', '11', '', '', '', '', ''),
(9, '8', '5', '7', '5', '11', '', '', '', '', ''),
(10, '9', '5', '7', '5', '11', '', '', '', '', ''),
(11, '10', '5', '7', '5', '11', '', '', '', '', ''),
(12, '11', '5', '7', '5', '11', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `model2`
--

CREATE TABLE IF NOT EXISTS `model2` (
  `id` int(4) NOT NULL,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
  `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
  `E` varchar(100) NOT NULL,
  `F` varchar(100) NOT NULL,
  `G` varchar(100) NOT NULL,
  `H` varchar(100) NOT NULL,
  `I` varchar(100) NOT NULL,
  `J` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `model2`
--

INSERT INTO `model2` (`id`, `A`, `B`, `C`, `D`, `E`, `F`, `G`, `H`, `I`, `J`) VALUES
(1, '11', '5', '7', '5', '11', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `satisfy`
--

CREATE TABLE IF NOT EXISTS `satisfy` (
  `id` int(4) NOT NULL,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
  `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
  `E` varchar(100) NOT NULL,
  `F` varchar(100) NOT NULL,
  `G` varchar(100) NOT NULL,
  `H` varchar(100) NOT NULL,
  `I` varchar(100) NOT NULL,
  `J` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `satisfy`
--

INSERT INTO `satisfy` (`id`, `A`, `B`, `C`, `D`, `E`, `F`, `G`, `H`, `I`, `J`) VALUES
(1, '1', '1', '1', '0', '0', '0', '0', '0', '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model2`
--
ALTER TABLE `model2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `satisfy`
--
ALTER TABLE `satisfy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `model`
--
ALTER TABLE `model`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `model2`
--
ALTER TABLE `model2`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `satisfy`
--
ALTER TABLE `satisfy`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
